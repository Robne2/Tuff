
import { GoogleGenAI } from "@google/genai";

export const askGeminiAboutOil = async (oilName: string, question: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Ești un expert în aromaterapie și uleiuri esențiale dōTERRA. 
      Utilizatorul întreabă despre uleiul: ${oilName}.
      Întrebarea este: ${question}
      Răspunde în limba română, într-un mod prietenos, informativ și profesionist. 
      Include detalii despre compuși chimici principali dacă este relevant, precauții și combinații sugerate.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Ne pare rău, a apărut o eroare la procesarea cererii tale.";
  }
};
