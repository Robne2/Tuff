
import { Oil } from '../types';

export const OILS_DATA: Oil[] = [
  {
    id: 'lavender',
    name: 'Lavender (Lavandă)',
    scientificName: 'Lavandula angustifolia',
    description: 'Cunoscută pentru proprietățile sale calmante și relaxante, Lavanda este unul dintre cele mai populare uleiuri esențiale.',
    benefits: [
      'Promovează relaxarea și un somn liniștit',
      'Calmează iritațiile ocazionale ale pielii',
      'Reduce tensiunea musculară'
    ],
    uses: [
      'Adaugă câteva picături în perna sau lenjeria de pat',
      'Aplică local pentru a calma pielea după expunerea la soare',
      'Difuzează seara pentru a crea o atmosferă relaxantă'
    ],
    aromaticDescription: 'Floral, ușor, proaspăt',
    color: '#9b7eb1', // Purple
    image: 'https://picsum.photos/seed/lavender/600/600'
  },
  {
    id: 'lemon',
    name: 'Lemon (Lămâie)',
    scientificName: 'Citrus limon',
    description: 'Un agent de curățare puternic care purifică aerul și suprafețele, oferind un impuls energetic pozitiv.',
    benefits: [
      'Curăță și purifică aerul și suprafețele',
      'Susține funcția respiratorie sănătoasă',
      'Promovează o stare de spirit pozitivă'
    ],
    uses: [
      'Adaugă în apă pentru un gust revigorant',
      'Folosește pentru a curăța blaturile de bucătărie',
      'Difuzează pentru a îmbunătăți concentrarea'
    ],
    aromaticDescription: 'Curat, proaspăt, citric',
    color: '#f9e04c', // Yellow
    image: 'https://picsum.photos/seed/lemon/600/600'
  },
  {
    id: 'peppermint',
    name: 'Peppermint (Mentă)',
    scientificName: 'Mentha piperita',
    description: 'Un ulei versatil care oferă o senzație de răcoare și claritate mentală, fiind ideal pentru energie.',
    benefits: [
      'Promovează funcția respiratorie sănătoasă',
      'Alină disconfortul digestiv ocazional',
      'Oferă un impuls de energie natural'
    ],
    uses: [
      'Aplică pe tâmple pentru a reduce senzația de tensiune',
      'Inhalează direct pentru o revigorare rapidă',
      'Adaugă în șampon pentru un masaj revigorant al scalpului'
    ],
    aromaticDescription: 'Mentolat, proaspăt, erbaceu',
    color: '#4fb8a1', // Mint Green
    image: 'https://picsum.photos/seed/peppermint/600/600'
  },
  {
    id: 'frankincense',
    name: 'Frankincense (Tămâie)',
    scientificName: 'Boswellia carterii',
    description: 'Considerat „Regele Uleiurilor”, Tămâia are beneficii extraordinare pentru sănătatea celulară și relaxare.',
    benefits: [
      'Susține funcția celulară sănătoasă',
      'Reduce imperfecțiunile pielii',
      'Induce sentimente de pace și satisfacție'
    ],
    uses: [
      'Aplică pe tălpi pentru a promova relaxarea',
      'Adaugă în crema de față pentru o piele radiantă',
      'Difuzează în timpul meditației sau rugăciunii'
    ],
    aromaticDescription: 'Rășinos, cald, picant',
    color: '#c99b5a', // Amber/Gold
    image: 'https://picsum.photos/seed/frankincense/600/600'
  },
  {
    id: 'tea-tree',
    name: 'Tea Tree (Arbore de Ceai)',
    scientificName: 'Melaleuca alternifolia',
    description: 'Renumit pentru proprietățile sale de curățare și regenerare, în special pentru piele.',
    benefits: [
      'Curăță și regenerează pielea',
      'Susține un sistem imunitar sănătos',
      'Protejează împotriva amenințărilor de mediu'
    ],
    uses: [
      'Aplică pe imperfecțiunile pielii',
      'Adaugă în balsamul de rufe pentru un miros proaspăt',
      'Folosește ca apă de gură naturală'
    ],
    aromaticDescription: 'Erbaceu, proaspăt, medicinal',
    color: '#6e8a4a', // Dark Green
    image: 'https://picsum.photos/seed/teatree/600/600'
  }
];
