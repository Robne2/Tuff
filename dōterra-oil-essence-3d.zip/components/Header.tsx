
import React from 'react';
import { Leaf } from 'lucide-react';

interface HeaderProps {
  onBack: () => void;
  showBack: boolean;
}

const Header: React.FC<HeaderProps> = ({ onBack, showBack }) => {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={onBack}
        >
          <div className="p-2 bg-emerald-50 rounded-lg group-hover:bg-emerald-100 transition-colors">
            <Leaf className="w-6 h-6 text-emerald-600" />
          </div>
          <h1 className="text-xl font-bold text-stone-800 tracking-tight">
            Oil<span className="text-emerald-600">Essence</span>
          </h1>
        </div>

        {showBack && (
          <button 
            onClick={onBack}
            className="text-stone-500 hover:text-stone-800 font-medium text-sm transition-colors flex items-center gap-1"
          >
            <span>&larr;</span> Înapoi la catalog
          </button>
        )}
      </div>
    </header>
  );
};

export default Header;
