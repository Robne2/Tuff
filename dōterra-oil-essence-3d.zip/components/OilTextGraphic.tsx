
import React from 'react';

interface OilTextGraphicProps {
  name: string;
  scientificName: string;
  color: string;
  className?: string;
}

const OilTextGraphic: React.FC<OilTextGraphicProps> = ({ name, scientificName, color, className = "" }) => {
  // Extract just the main name (before any parentheses)
  const displayName = name.split(' (')[0];
  
  return (
    <div 
      className={`relative w-full h-full flex flex-col items-center justify-center p-8 overflow-hidden transition-all duration-700 ${className}`}
      style={{ backgroundColor: `${color}10` }} // Very light version of the oil color as background
    >
      {/* Decorative large background text */}
      <div 
        className="absolute inset-0 flex items-center justify-center opacity-[0.03] select-none pointer-events-none"
        style={{ color: color }}
      >
        <span className="text-[20vw] font-serif font-bold whitespace-nowrap uppercase">
          {displayName}
        </span>
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center space-y-4">
        <div 
          className="w-16 h-1 mx-auto rounded-full mb-8"
          style={{ backgroundColor: color }}
        />
        
        <h2 
          className="text-4xl md:text-6xl font-serif font-bold tracking-tight"
          style={{ color: color }}
        >
          {displayName}
        </h2>
        
        <p className="text-stone-400 font-medium tracking-[0.3em] uppercase text-[10px] md:text-xs">
          {scientificName}
        </p>
        
        <div className="pt-4 flex items-center justify-center gap-3">
          <span className="text-[9px] font-black uppercase tracking-[0.5em] text-stone-300">CPTG</span>
          <div className="w-1 h-1 rounded-full bg-stone-200" />
          <span className="text-[9px] font-black uppercase tracking-[0.5em] text-stone-300">15 ML</span>
        </div>
      </div>
      
      {/* Abstract circle shapes */}
      <div 
        className="absolute -bottom-20 -right-20 w-64 h-64 rounded-full opacity-[0.05] blur-3xl"
        style={{ backgroundColor: color }}
      />
      <div 
        className="absolute -top-20 -left-20 w-64 h-64 rounded-full opacity-[0.05] blur-3xl"
        style={{ backgroundColor: color }}
      />
    </div>
  );
};

export default OilTextGraphic;
