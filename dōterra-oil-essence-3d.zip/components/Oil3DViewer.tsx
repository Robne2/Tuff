
import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';

interface Oil3DViewerProps {
  labelColor: string;
  name: string;
  scientificName: string;
}

const Oil3DViewer: React.FC<Oil3DViewerProps> = ({ labelColor, name, scientificName }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mousePos = useRef({ x: 0, y: 0 });
  const isHovered = useRef(false);

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xffffff);

    const camera = new THREE.PerspectiveCamera(28, width / height, 0.1, 1000);
    camera.position.set(0, 0.2, 6.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    containerRef.current.appendChild(renderer.domElement);

    const bottleGroup = new THREE.Group();
    bottleGroup.position.y = -1.0;

    // --- PROCEDURAL LABEL ---
    const canvas = document.createElement('canvas');
    canvas.width = 2048;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      ctx.translate(250, 512);
      ctx.rotate(-Math.PI / 2);
      ctx.fillStyle = '#4a4a4a';
      ctx.font = 'bold 160px "Playfair Display", serif';
      ctx.textAlign = 'center';
      ctx.fillText('dōTERRA®', 0, 0);
      ctx.restore();

      const blockWidth = 950;
      const blockHeight = 850;
      const blockX = 420;
      const blockY = 87;
      ctx.fillStyle = labelColor;
      ctx.beginPath();
      const r = 80; 
      ctx.moveTo(blockX + r, blockY);
      ctx.lineTo(blockX + blockWidth - r, blockY);
      ctx.quadraticCurveTo(blockX + blockWidth, blockY, blockX + blockWidth, blockY + r);
      ctx.lineTo(blockX + blockWidth, blockY + blockHeight - r);
      ctx.quadraticCurveTo(blockX + blockWidth, blockY + blockHeight, blockX + blockWidth - r, blockY + blockHeight);
      ctx.lineTo(blockX + r, blockY + blockHeight);
      ctx.quadraticCurveTo(blockX, blockY + blockHeight, blockX, blockY + blockHeight - r);
      ctx.lineTo(blockX, blockY + r);
      ctx.quadraticCurveTo(blockX, blockY, blockX + r, blockY);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 150px "Inter", sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(name.split(' ')[0], blockX + 80, blockY + 300);
      ctx.font = '70px "Inter", sans-serif';
      ctx.fillText('Essential Oil', blockX + 80, blockY + 420);

      ctx.save();
      ctx.translate(1750, 512);
      ctx.rotate(-Math.PI / 2);
      ctx.fillStyle = '#333333';
      ctx.textAlign = 'center';
      ctx.font = 'italic 55px "Inter", sans-serif';
      ctx.fillText(scientificName, 0, -40);
      ctx.font = 'bold 60px "Inter", sans-serif';
      ctx.fillText('15 mL', 0, 80);
      ctx.restore();
    }

    const labelTexture = new THREE.CanvasTexture(canvas);
    labelTexture.anisotropy = 16;
    labelTexture.wrapS = THREE.RepeatWrapping;

    // --- MATERIALS ---
    const amberGlassMat = new THREE.MeshPhysicalMaterial({ 
      color: 0x3d1f0e, 
      roughness: 0.05, 
      metalness: 0.0,
      transparent: true,
      opacity: 0.95,
      transmission: 0.3,
      thickness: 1.5,
      ior: 1.52,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02,
    });

    const liquidMat = new THREE.MeshPhysicalMaterial({
      color: labelColor,
      emissive: labelColor,
      emissiveIntensity: 0.1,
      transparent: true,
      opacity: 0.6,
      transmission: 0.9,
      ior: 1.47,
      thickness: 0.2,
    });

    // --- GEOMETRY ---
    // Bottle Body
    const bottleBody = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 2.3, 64), amberGlassMat);
    bottleBody.castShadow = true;
    bottleGroup.add(bottleBody);

    // Liquid Inside
    const liquidBody = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.65, 2.0, 32), liquidMat);
    liquidBody.position.y = -0.1;
    bottleGroup.add(liquidBody);

    // Label
    const label = new THREE.Mesh(
      new THREE.CylinderGeometry(0.76, 0.76, 1.7, 64, 1, true),
      new THREE.MeshStandardMaterial({ map: labelTexture, roughness: 0.7, transparent: true })
    );
    label.rotation.y = Math.PI * 0.94;
    bottleGroup.add(label);

    // Cap & Ribbing
    const capMat = new THREE.MeshStandardMaterial({ color: 0x080808, roughness: 0.4 });
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 0.9, 64), capMat);
    cap.position.y = 1.6;
    cap.castShadow = true;
    bottleGroup.add(cap);

    const ribGeom = new THREE.BoxGeometry(0.015, 0.85, 0.03);
    for (let i = 0; i < 50; i++) {
      const rib = new THREE.Mesh(ribGeom, capMat);
      const angle = (i / 50) * Math.PI * 2;
      rib.position.set(Math.cos(angle) * 0.705, 1.6, Math.sin(angle) * 0.705);
      rib.rotation.y = -angle;
      bottleGroup.add(rib);
    }

    // Floor Reflection
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(10, 10),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1, transparent: true, opacity: 0.75 })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -1.16;
    floor.receiveShadow = true;
    scene.add(floor);

    // --- LIGHTS ---
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const staticKeyLight = new THREE.DirectionalLight(0xffffff, 0.8);
    staticKeyLight.position.set(5, 5, 5);
    scene.add(staticKeyLight);

    const rimLight = new THREE.PointLight(0xffffff, 1.5);
    rimLight.position.set(0, 4, -5);
    scene.add(rimLight);

    // Dynamic Cursor Light
    const cursorLight = new THREE.PointLight(0xffffff, 0);
    cursorLight.position.set(0, 1, 3);
    scene.add(cursorLight);

    scene.add(bottleGroup);

    // --- ANIMATION LOOP ---
    let time = 0;
    const animate = () => {
      time += 0.01;
      requestAnimationFrame(animate);

      // Liquid shimmer pulse
      const pulseIntensity = 0.1 + (Math.sin(time * 2) * 0.05);
      liquidMat.emissiveIntensity = isHovered.current ? pulseIntensity * 3 : pulseIntensity;
      
      // Dynamic rotation
      const targetRotationSpeed = isHovered.current ? 0.008 : 0.003;
      bottleGroup.rotation.y += targetRotationSpeed;

      // Update cursor light
      if (isHovered.current) {
        cursorLight.intensity = THREE.MathUtils.lerp(cursorLight.intensity, 2.5, 0.1);
        cursorLight.position.x = THREE.MathUtils.lerp(cursorLight.position.x, mousePos.current.x * 3, 0.1);
        cursorLight.position.y = THREE.MathUtils.lerp(cursorLight.position.y, mousePos.current.y * 2 + 1, 0.1);
      } else {
        cursorLight.intensity = THREE.MathUtils.lerp(cursorLight.intensity, 0, 0.1);
      }

      renderer.render(scene, camera);
    };
    animate();

    // --- INTERACTION HANDLERS ---
    const onMouseMove = (event: MouseEvent) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      mousePos.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mousePos.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const onMouseEnter = () => isHovered.current = true;
    const onMouseLeave = () => isHovered.current = false;

    const container = containerRef.current;
    container.addEventListener('mousemove', onMouseMove);
    container.addEventListener('mouseenter', onMouseEnter);
    container.addEventListener('mouseleave', onMouseLeave);

    const handleResize = () => {
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', onMouseMove);
      container.removeEventListener('mouseenter', onMouseEnter);
      container.removeEventListener('mouseleave', onMouseLeave);
      if (container) container.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [labelColor, name, scientificName]);

  return (
    <div className="relative w-full h-[450px] md:h-[650px] bg-white rounded-[3.5rem] overflow-hidden shadow-[inset_0_0_100px_rgba(0,0,0,0.03)] border border-stone-100 group">
      <div ref={containerRef} className="w-full h-full cursor-crosshair" />
      
      {/* Dynamic Overlay HUD */}
      <div className="absolute top-10 left-10 right-10 flex justify-between items-start pointer-events-none">
        <div className="bg-white/40 backdrop-blur-xl px-5 py-2.5 rounded-2xl border border-white/50 shadow-sm transition-all duration-500 group-hover:bg-white/80">
          <span className="text-[10px] font-black uppercase tracking-[0.5em] text-stone-900 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Active Fluid Probe
          </span>
        </div>
        <div className="text-right">
          <p className="text-[9px] font-black uppercase tracking-[0.4em] text-stone-300">Refractive Index</p>
          <p className="text-xs font-serif italic text-stone-500">1.47 nD</p>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none">
         <div className="bg-stone-900 text-white px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-[0.3em] flex items-center gap-2">
           <svg className="w-3 h-3 animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
           </svg>
           Move to inspect shimmer
         </div>
      </div>
    </div>
  );
};

export default Oil3DViewer;
